# Pan-Card-Detection > 2024-07-19 4:04pm
https://universe.roboflow.com/deep-learningcomputer-vision/pan-card-detection-hlxd1

Provided by a Roboflow user
License: MIT

